Feature('demo');

Scenario('Get all employee data',  async({ I }) => {
    const res = await I.sendGetRequest('api/v1/employees');
    // I.seeResponseCodeIsSuccessful();
    
    // console.log(res);  
    console.log(res.data);
});
