Feature('demo');
Scenario('Get a single employee data',  async({ I }) => {
    const id = 24;
    const res = await I.sendDeleteRequest('api/v1/delete/${id}');
    I.seeResponseCodeIsSuccessful();
    console.log(res);
    // I.seeResponseCodeIs(200);
    // console.log(res.data);

});