Feature('demo');
//POST
Scenario('Create new record in database',  async({ I }) => {
    const res = await I.sendPostRequest('api/v1/create',{       
        "name":"avsa",
        "salary":"123",
        "age":"23"
    });
    // I.seeResponseCodeIsSuccessful();
    I.seeResponseCodeIs(200);
    console.log(res.data);
});
